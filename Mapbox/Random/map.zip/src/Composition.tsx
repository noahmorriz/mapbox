import { useEffect, useRef, useState } from 'react';
import {
  AbsoluteFill,
  continueRender,
  delayRender,
  useCurrentFrame,
  useVideoConfig,
  spring,
  interpolate,
} from 'remotion';
import mapboxgl, { AnyLayer, VectorSourceSpecification } from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { defaultCountry, countries, getCountry } from './countryData';
import { getIconByName } from './icons';
import { FaInfoCircle } from 'react-icons/fa';
import { renderToString } from 'react-dom/server';

// ======================================================================
// MAPBOX CONFIGURATION
// ======================================================================
mapboxgl.accessToken =
  'pk.eyJ1Ijoibm9haG1vcnJpeiIsImEiOiJjbThoZnZvbTAwMWoyMnNxMGQ1MGRyZ3VqIn0.HtrVBbWJzrviJZJn7vr66g';

// ======================================================================
// COMPOSITION SETTINGS
// ======================================================================

/**
 * USAGE EXAMPLES:
 * 
 * // Basic usage with flag icon
 * <MapboxAnimation 
 *   countryCode="USA" 
 *   iconType="flag"
 * />
 * 
 * // Show skull icon with text label
 * <MapboxAnimation 
 *   countryCode="RUS" 
 *   iconType="skull"
 *   showText={true}
 *   customText="Danger Zone"
 * />
 * 
 * // No icon, just text
 * <MapboxAnimation 
 *   countryCode="CAN" 
 *   iconType="none"
 *   showText={true}
 * />
 */

// List of large countries that span multiple time zones
const LARGE_COUNTRIES = ['RUS', 'USA', 'CAN', 'CHN', 'BRA', 'AUS'];

// ======================================================================
// UI CONTROLS & TEXT SETTINGS
// ======================================================================

// Error message settings
const ERROR_MESSAGE_SETTINGS = {
  color: 'white',
  textAlign: 'center' as const,
  padding: '2rem',
  backgroundColor: 'rgba(255, 0, 0, 0.7)',
};

// Mapbox marker settings
const MARKER_SETTINGS = {
  anchor: 'center' as const,
  rotationAlignment: 'map' as const,
  pitchAlignment: 'map' as const,
};

// Helper function to render an icon to HTML string
const renderIconToHTML = (iconType: string, size: number, color: string) => {
  if (!iconType || iconType === 'none') {
    return '';
  }
  
  const IconComponent = getIconByName(iconType);
  if (!IconComponent) {
    return '';
  }
  
  return renderToString(<IconComponent size={size} color={color} />);
};

// ======================================================================
// ANIMATION SETTINGS
// ======================================================================

// Default animation settings
const DEFAULT_ANIMATION_SETTINGS = {
  // Camera animation settings
  camera: {
    initialRotation: 0,
    finalRotation: 45,
    initialPitch: 0,
    finalPitch: 30,
    rotationDamping: 150,
    rotationStiffness: 10,
    rotationMass: 20,
    pitchDamping: 150,
    pitchStiffness: 10,
    pitchMass: 20,
  },
  // Highlight animation settings
  highlight: {
    fillColor: '#0C8E8E',
    fillOpacityTarget: 0.5,
    lineColor: '#0C8E8E',
    lineWidth: 3,
    lineOpacityTarget: 1,
    fillAnimationDamping: 40,
    fillAnimationStiffness: 30,
    fillAnimationMass: 1.5,
    lineAnimationDamping: 35,
    lineAnimationStiffness: 25,
    lineAnimationMass: 1.5,
    labelOpacityTarget: 1,
    labelAnimationDamping: 40,
    labelAnimationStiffness: 30,
    labelAnimationMass: 1.5,
  },
  // General settings
  general: {
    animationStartFrame: 10,
    highlightDelayFrames: 45, // Delay before highlight animation starts
    labelDelayFrames: 60, // Delay before label appears
    padding: 20,
    backgroundColor: '#111',
    mapStyle: 'mapbox://styles/mapbox/dark-v11', // Default to a standard Mapbox style
    renderWorldCopies: false,
    fadeDuration: 0, // Ensuring no fade between styles
  },
  // UI styling settings
  ui: {
    // Icon styling
    iconSize: 200,
    iconColor: '#FFFFFF',
    iconDropShadow: '0px 0px 10px rgba(0, 0, 0, 0.7)',
    iconScale: 1.2,
    iconBottomMargin: '5px',
    
    // Label styling
    labelPadding: '8px 12px',
    labelBorderRadius: '4px',
    labelBackgroundColor: 'rgba(0, 0, 0, 0.5)',
    labelBoxShadow: '0 2px 5px rgba(0, 0, 0, 0.2)',
    
    // Text styling
    textFontSize: '18px',
    textFontWeight: 'bold',
    textColor: '#FFFFFF',
    textMarginLeft: '8px',
    
    // Info box styling
    infoBackgroundColor: 'rgba(255, 255, 255, 0.8)',
    infoTextColor: '#000000',
    infoPadding: '8px 12px',
    infoBorderRadius: '4px',
    infoFontSize: '14px',
    infoMaxWidth: '200px',
    infoIconSize: 30,
    infoIconColor: '#333333',
    infoBoxShadow: '0 2px 5px rgba(0,0,0,0.2)',
  }
};

// Map layer settings
const MAP_LAYER_SETTINGS = {
  countryBoundaries: {
    id: 'country-boundaries',
    source: {
      type: 'vector',
      url: 'mapbox://mapbox.country-boundaries-v1'
    } as VectorSourceSpecification,
    sourceLayer: 'country_boundaries',
    type: 'fill' as 'fill',
    paint: {
      fillColor: '#888888',
      fillOpacity: 0.1
    }
  },
  countryFill: {
    id: 'country-fill',
    source: {
      type: 'vector',
      url: 'mapbox://mapbox.country-boundaries-v1'
    } as VectorSourceSpecification,
    sourceLayer: 'country_boundaries',
    type: 'fill' as 'fill',
  },
  countryOutline: {
    id: 'country-outline',
    source: {
      type: 'vector',
      url: 'mapbox://mapbox.country-boundaries-v1'
    } as VectorSourceSpecification,
    sourceLayer: 'country_boundaries',
    type: 'line' as 'line',
  }
};

// ======================================================================
// TYPE DEFINITIONS
// ======================================================================

export interface AnimationSettings {
  camera: {
    initialRotation: number;
    finalRotation: number;
    initialPitch: number;
    finalPitch: number;
    rotationDamping: number;
    rotationStiffness: number;
    rotationMass: number;
    pitchDamping: number;
    pitchStiffness: number;
    pitchMass: number;
  };
  highlight: {
    fillColor: string;
    fillOpacityTarget: number;
    lineColor: string;
    lineWidth: number;
    lineOpacityTarget: number;
    fillAnimationDamping: number;
    fillAnimationStiffness: number;
    fillAnimationMass: number;
    lineAnimationDamping: number;
    lineAnimationStiffness: number;
    lineAnimationMass: number;
    labelOpacityTarget: number;
    labelAnimationDamping: number;
    labelAnimationStiffness: number;
    labelAnimationMass: number;
  };
  general: {
    animationStartFrame: number;
    highlightDelayFrames: number;
    labelDelayFrames: number;
    padding: number;
    backgroundColor: string;
    mapStyle: string;
    renderWorldCopies: boolean;
    fadeDuration: number;
  };
  ui: {
    // Icon styling
    iconSize: number;
    iconColor: string;
    iconDropShadow: string;
    iconScale: number;
    iconBottomMargin: string;
    
    // Label styling
    labelPadding: string;
    labelBorderRadius: string;
    labelBackgroundColor: string;
    labelBoxShadow: string;
    
    // Text styling
    textFontSize: string;
    textFontWeight: string;
    textColor: string;
    textMarginLeft: string;
    
    // Info box styling
    infoBackgroundColor: string;
    infoTextColor: string;
    infoPadding: string;
    infoBorderRadius: string;
    infoFontSize: string;
    infoMaxWidth: string;
    infoIconSize: number;
    infoIconColor: string;
    infoBoxShadow: string;
  };
}

interface MapboxAnimationProps {
  countryCode?: string;
  customText?: string;
  /**
   * Controls which icon to display (if any)
   * Available icon types:
   * 
   * Basic mapping icons:
   * - "marker"
   * - "pin"
   * - "marker-alt"
   * - "location"
   * - "location-fill"
   * - "compass"
   * - "arrow"
   * - "gps"
   * 
   * Information icons:
   * - "info"
   * - "warning"
   * - "cross"
   * - "star"
   * 
   * Special icons:
   * - "flag"
   * - "skull"
   * - "death-skull"
   * - "target"
   * 
   * Other:
   * - "none" - No icon
   * 
   * @example
   * // Show a flag icon:
   * <MapboxAnimation iconType="flag" />
   * 
   * // Show a death skull icon:
   * <MapboxAnimation iconType="death-skull" />
   * 
   * // No icon:
   * <MapboxAnimation iconType="none" />
   * 
   * @default "marker"
   */
  iconType?: string;
  /**
   * Controls whether to display any icon.
   * Set to false to hide the icon completely, regardless of iconType.
   * 
   * @example
   * // Hide icon completely:
   * <MapboxAnimation showIcon={false} />
   * 
   * @default true
   */
  showIcon?: boolean;
  /**
   * Controls whether to display the text label
   * @default false
   */
  showText?: boolean;
  /**
   * Disables the fallback icon when both icon and text are hidden.
   * By default, when both showIcon and showText are false, a marker icon is shown as fallback.
   * Set this to true to hide all markers completely.
   * 
   * @default false
   */
  disableFallbackIcon?: boolean;
  /**
   * Controls whether to apply a drop shadow effect to the icon.
   * Set to false to disable the drop shadow.
   * 
   * @example
   * // Disable icon drop shadow:
   * <MapboxAnimation enableIconDropShadow={false} />
   * 
   * @default true
   */
  enableIconDropShadow?: boolean;
  /**
   * Quick icon customization options
   */
  iconSettings?: {
    size?: number;
    color?: string;
    scale?: number;
  };
  /**
   * Quick text customization options
   */
  textSettings?: {
    fontSize?: string;
    color?: string;
    fontWeight?: string;
  };
  /**
   * Quick info box customization options
   */
  infoSettings?: {
    maxWidth?: string;
    fontSize?: string;
    backgroundColor?: string;
    textColor?: string;
  };
  backgroundColor?: string;
  highlightColor?: string;
  additionalInfo?: string;
  settings?: Partial<AnimationSettings>;
}

// ======================================================================
// MAIN COMPONENT
// ======================================================================

export const MapboxAnimation: React.FC<MapboxAnimationProps> = ({ 
  countryCode = "KOR",
  customText,
  iconType = "death-skull", // Default to the marker icon
  showIcon = true,
  showText = false,
  disableFallbackIcon = true,
  enableIconDropShadow = true,
  iconSettings,
  textSettings,
  infoSettings,
  backgroundColor,
  highlightColor,
  additionalInfo,
  settings = {}
}) => {
  // Get the country data from the code
  const countryData = countryCode ? (countries[countryCode] || getCountry(countryCode) || defaultCountry) : defaultCountry;
  
  // Determine if we should show an icon
  const shouldShowIcon = iconType !== "none" && showIcon;
  
  // ======================================================================
  // STATE & REFS
  // ======================================================================
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const labelMarkerRef = useRef<mapboxgl.Marker | null>(null);
  const infoMarkerRef = useRef<mapboxgl.Marker | null>(null);
  const frameRenderHandleRef = useRef<number | null>(null);
  
  const { fps } = useVideoConfig();
  const frame = useCurrentFrame();
  const [initialRenderHandle] = useState(() => delayRender('Loading map...'));
  const [hasError, setHasError] = useState(false);
  const [mapLayersReady, setMapLayersReady] = useState(false);

  // ======================================================================
  // SETTINGS & COUNTRY DATA CONFIGURATION
  // ======================================================================
  
  // Check if this is a large country
  const isLargeCountry = LARGE_COUNTRIES.includes(countryData.alpha3);
  
  // Apply custom highlight color if provided
  const mergedHighlightSettings = {
    ...DEFAULT_ANIMATION_SETTINGS.highlight,
    ...(highlightColor ? {
      fillColor: highlightColor,
      lineColor: highlightColor,
    } : {}),
    ...settings.highlight,
  };
  
  // Merge default settings with provided settings and country-specific overrides
  const mergedSettings: AnimationSettings = {
    camera: { 
      ...DEFAULT_ANIMATION_SETTINGS.camera, 
      ...(isLargeCountry ? { 
        finalRotation: 20, 
        finalPitch: 15,
        rotationStiffness: 8,
        pitchStiffness: 8, 
      } : {}),
      ...settings.camera 
    },
    highlight: mergedHighlightSettings,
    general: { 
      ...DEFAULT_ANIMATION_SETTINGS.general,
      ...(backgroundColor ? { backgroundColor } : {}),
      ...(isLargeCountry ? { 
        renderWorldCopies: true 
      } : {}),
      ...settings.general 
    },
    ui: {
      ...DEFAULT_ANIMATION_SETTINGS.ui,
      // Apply quick iconSettings if provided
      ...(iconSettings ? {
        iconSize: iconSettings.size || DEFAULT_ANIMATION_SETTINGS.ui.iconSize,
        iconColor: iconSettings.color || DEFAULT_ANIMATION_SETTINGS.ui.iconColor,
        iconScale: iconSettings.scale || DEFAULT_ANIMATION_SETTINGS.ui.iconScale,
      } : {}),
      // Apply quick textSettings if provided
      ...(textSettings ? {
        textFontSize: textSettings.fontSize || DEFAULT_ANIMATION_SETTINGS.ui.textFontSize,
        textColor: textSettings.color || DEFAULT_ANIMATION_SETTINGS.ui.textColor,
        textFontWeight: textSettings.fontWeight || DEFAULT_ANIMATION_SETTINGS.ui.textFontWeight,
      } : {}),
      // Apply quick infoSettings if provided
      ...(infoSettings ? {
        infoMaxWidth: infoSettings.maxWidth || DEFAULT_ANIMATION_SETTINGS.ui.infoMaxWidth,
        infoFontSize: infoSettings.fontSize || DEFAULT_ANIMATION_SETTINGS.ui.infoFontSize,
        infoBackgroundColor: infoSettings.backgroundColor || DEFAULT_ANIMATION_SETTINGS.ui.infoBackgroundColor,
        infoTextColor: infoSettings.textColor || DEFAULT_ANIMATION_SETTINGS.ui.infoTextColor,
      } : {}),
      ...settings.ui,
    }
  };

  // Destructure settings for easier access
  const { camera, highlight, general, ui } = mergedSettings;
  const { animationStartFrame, padding, mapStyle, renderWorldCopies } = general;
  const bgColor = general.backgroundColor;
  const highlightDelayFrames = general.highlightDelayFrames || 0;
  const labelDelayFrames = general.labelDelayFrames || 0;

  // ======================================================================
  // ANIMATION CALCULATIONS
  // ======================================================================
  
  // Animate camera parameters
  const bearing = spring({
    frame,
    fps,
    from: camera.initialRotation,
    to: camera.finalRotation,
    config: { 
      damping: camera.rotationDamping, 
      stiffness: camera.rotationStiffness, 
      mass: camera.rotationMass 
    },
  });
  
  const pitch = spring({
    frame,
    fps,
    from: camera.initialPitch,
    to: camera.finalPitch,
    config: { 
      damping: camera.pitchDamping, 
      stiffness: camera.pitchStiffness, 
      mass: camera.pitchMass 
    },
  });
  
  // Use the selected country's center coordinates
  const animatedCenter: [number, number] = countryData.coordinates;
  
  // Animate the zoom level using spring function
  const animatedZoom = spring({
    frame,
    fps,
    from: Math.max(countryData.zoomLevel - 1, 0),
    to: countryData.zoomLevel,
    config: {
      damping: 60,
      stiffness: 10,
      mass: 1,
    },
  });

  // Calculate total delay for highlight animation
  const totalHighlightDelay = animationStartFrame + highlightDelayFrames;

  // Calculate total delay for label animation
  const totalLabelDelay = animationStartFrame + labelDelayFrames;

  // Animate country highlight opacities with delayed start
  const fillOpacity = spring({
    frame: Math.max(0, frame - totalHighlightDelay),
    fps,
    from: 0,
    to: highlight.fillOpacityTarget,
    config: { 
      damping: highlight.fillAnimationDamping, 
      stiffness: highlight.fillAnimationStiffness, 
      mass: highlight.fillAnimationMass 
    },
  });
  
  const lineOpacity = spring({
    frame: Math.max(0, frame - totalHighlightDelay),
    fps,
    from: 0,
    to: highlight.lineOpacityTarget,
    config: { 
      damping: highlight.lineAnimationDamping, 
      stiffness: highlight.lineAnimationStiffness, 
      mass: highlight.lineAnimationMass 
    },
  });

  // Animate label properties with delayed start
  const labelOpacity = spring({
    frame: Math.max(0, frame - totalLabelDelay),
    fps,
    from: 0,
    to: highlight.labelOpacityTarget,
    config: {
      damping: highlight.labelAnimationDamping,
      stiffness: highlight.labelAnimationStiffness,
      mass: highlight.labelAnimationMass,
    }
  });

  const labelScale = spring({
    frame: Math.max(0, frame - totalLabelDelay),
    fps,
    from: 0.8,
    to: 1,
    config: {
      damping: 35,
      stiffness: 40,
      mass: 1.2,
    },
  });

  const labelY = interpolate(
    spring({
      frame: Math.max(0, frame - totalLabelDelay),
      fps,
      from: 0,
      to: 1,
      config: {
        damping: 30,
        stiffness: 35,
        mass: 1,
      },
    }),
    [0, 1],
    [10, 0]
  );

  // Additional info animation (delayed even more)
  const infoOpacity = additionalInfo ? spring({
    frame: Math.max(0, frame - totalLabelDelay - 15), // Add extra delay
    fps,
    from: 0,
    to: 1,
    config: {
      damping: 30,
      stiffness: 30,
      mass: 1,
    }
  }) : 0;

  // ======================================================================
  // SAFETY TIMEOUT
  // ======================================================================
  
  // Safety timeout to ensure rendering continues even if map fails to load
  useEffect(() => {
    const safetyTimeout = setTimeout(() => {
      console.warn('Map load safety timeout triggered - continuing render anyway');
      setHasError(true);
      continueRender(initialRenderHandle);
    }, 20000); // 20 seconds max wait time
    
    return () => {
      clearTimeout(safetyTimeout);
    };
  }, [initialRenderHandle]);

  // ======================================================================
  // MAP INITIALIZATION
  // ======================================================================
  
  // Initialize the map
  useEffect(() => {
    if (!mapContainerRef.current) {
      // If map container isn't available, don't block rendering
      setHasError(true);
      continueRender(initialRenderHandle);
      return;
    }

    let mapInstance: mapboxgl.Map | null = null;
    let loadTimeout: NodeJS.Timeout | null = null;
    
    // Set a timeout specifically for map loading
    loadTimeout = setTimeout(() => {
      console.error('Map load timeout - continuing without map');
      setHasError(true);
      continueRender(initialRenderHandle);
    }, 15000); // 15 second timeout for map loading
    
    try {
      mapInstance = new mapboxgl.Map({
        container: mapContainerRef.current,
        style: mapStyle,
        center: countryData.coordinates,
        zoom: Math.max(countryData.zoomLevel - 1, 0), // Start slightly zoomed out
        bearing: camera.initialRotation,
        pitch: camera.initialPitch,
        interactive: false,
        attributionControl: false,
        fadeDuration: 0,
        preserveDrawingBuffer: true,
        antialias: true,
        renderWorldCopies,
        projection: { name: 'mercator' }
      });
      
      // Store the map instance in ref for access
      mapRef.current = mapInstance;
    } catch (error) {
      console.error('Map initialization failed:', error);
      setHasError(true);
      if (loadTimeout) clearTimeout(loadTimeout);
      continueRender(initialRenderHandle);
      return;
    }

    // Handle load event
    mapInstance.on('load', () => {
      if (loadTimeout) clearTimeout(loadTimeout);
      
      try {
        // Simplify the style: remove extraneous layers
        const style = mapInstance.getStyle();
        if (style && style.layers) {
          style.layers.forEach((layer: AnyLayer) => {
            if (
              layer.id.includes('label') ||
              layer.id.includes('poi') ||
              layer.id.includes('road') ||
              layer.id.includes('symbol')
            ) {
              try {
                mapInstance?.removeLayer(layer.id);
              } catch (e) {
                // Ignore removal errors
                console.warn(`Failed to remove layer ${layer.id}`, e);
              }
            }
          });
        }
        
        // Set padding to load extra tiles around the visible area
        mapInstance.setPadding({
          top: padding,
          bottom: padding,
          left: padding,
          right: padding,
        });

        // Add map layers
        try {
          // 1. Basic country boundaries
          mapInstance.addLayer({
            id: MAP_LAYER_SETTINGS.countryBoundaries.id,
            source: MAP_LAYER_SETTINGS.countryBoundaries.source,
            'source-layer': MAP_LAYER_SETTINGS.countryBoundaries.sourceLayer,
            type: MAP_LAYER_SETTINGS.countryBoundaries.type,
            paint: {
              'fill-color': MAP_LAYER_SETTINGS.countryBoundaries.paint.fillColor,
              'fill-opacity': MAP_LAYER_SETTINGS.countryBoundaries.paint.fillOpacity
            }
          });

          // 2. Highlighted country fill
          mapInstance.addLayer({
            id: MAP_LAYER_SETTINGS.countryFill.id,
            source: MAP_LAYER_SETTINGS.countryFill.source,
            'source-layer': MAP_LAYER_SETTINGS.countryFill.sourceLayer,
            type: MAP_LAYER_SETTINGS.countryFill.type,
            paint: {
              'fill-color': highlight.fillColor,
              'fill-opacity': 0
            },
            filter: ['==', ['get', 'iso_3166_1_alpha_3'], countryData.alpha3]
          });

          // 3. Highlighted country outline with improved styling
          mapInstance.addLayer({
            id: MAP_LAYER_SETTINGS.countryOutline.id,
            source: MAP_LAYER_SETTINGS.countryOutline.source,
            'source-layer': MAP_LAYER_SETTINGS.countryOutline.sourceLayer,
            type: MAP_LAYER_SETTINGS.countryOutline.type,
            paint: {
              'line-color': highlight.lineColor,
              'line-width': highlight.lineWidth,
              'line-opacity': 0,
              'line-blur': 0.5 // Add blur for anti-aliasing
            },
            layout: {
              'line-join': 'round', // Round joins for smoother corners
              'line-cap': 'round' // Round caps for smoother ends
            },
            filter: ['==', ['get', 'iso_3166_1_alpha_3'], countryData.alpha3]
          });
          
          setMapLayersReady(true);
        } catch (layerError) {
          console.error('Error adding map layers:', layerError);
          // Continue even if layer addition fails
          setMapLayersReady(true);
        }
        
        // Create and add the main label marker
        const createLabelMarker = () => {
          const markerContainer = document.createElement('div');
          markerContainer.className = 'mapbox-marker-container';
          markerContainer.style.display = 'flex';
          markerContainer.style.flexDirection = 'column';
          markerContainer.style.alignItems = 'center';
          markerContainer.style.pointerEvents = 'none';
          markerContainer.style.position = 'relative';
          markerContainer.style.transform = 'translateY(0px) scale(1)';
          
          // Create main container for text and icon
          const labelContainer = document.createElement('div');
          labelContainer.className = 'label-container';
          labelContainer.style.display = 'flex';
          labelContainer.style.alignItems = 'center';
          labelContainer.style.borderRadius = ui.labelBorderRadius;
          labelContainer.style.padding = ui.labelPadding;
          labelContainer.style.opacity = '0'; // Start invisible
          
          // Apply background and shadow to label container if text is shown
          if (showText) {
            labelContainer.style.backgroundColor = ui.labelBackgroundColor;
            labelContainer.style.boxShadow = ui.labelBoxShadow;
          }
          
          // Create text element
          const textElement = document.createElement('div');
          textElement.className = 'marker-text';
          textElement.textContent = customText || countryData.name;
          textElement.style.color = ui.textColor;
          textElement.style.fontSize = ui.textFontSize;
          textElement.style.fontWeight = ui.textFontWeight;
          textElement.style.willChange = 'opacity, transform'; // Optimization for animation
          textElement.style.display = showText ? 'block' : 'none'; // Show text only if showText is true
          if (showText) {
            textElement.style.marginLeft = ui.textMarginLeft;
          }
          
          // Add icon element if showIcon is true (icon is not NONE)
          if (shouldShowIcon) {
            const iconElement = document.createElement('div');
            iconElement.className = 'marker-icon';
            // Add drop shadow and positioning styles to make the icon stand out
            if (enableIconDropShadow) {
              iconElement.style.filter = ui.iconDropShadow;
            }
            iconElement.style.marginBottom = ui.iconBottomMargin;
            iconElement.style.transform = `scale(${ui.iconScale})`;
            
            // Use the icon type to determine which icon to display
            const iconColor = ui.iconColor;
            
            // Convert React Icon to HTML string with size from settings
            iconElement.innerHTML = renderIconToHTML(iconType, ui.iconSize, iconColor);
            
            // Add margin to icon if text is also shown
            if (showText) {
              iconElement.style.marginRight = '8px';
            }
            
            labelContainer.appendChild(iconElement);
          }
          
          // Add text to container if showText is true
          labelContainer.appendChild(textElement);
          
          // If both icon and text are hidden, show a marker icon as fallback
          // UNLESS fallback is explicitly disabled or showIcon is explicitly false
          if (!shouldShowIcon && !showText && !disableFallbackIcon && showIcon !== false) {
            console.warn('No icon or text selected. Displaying marker icon as fallback.');
            const iconElement = document.createElement('div');
            iconElement.className = 'marker-icon';
            if (enableIconDropShadow) {
              iconElement.style.filter = ui.iconDropShadow;
            }
            iconElement.innerHTML = renderIconToHTML("marker", ui.iconSize, ui.iconColor);
            labelContainer.appendChild(iconElement);
          }
          
          // Add label container to marker container
          markerContainer.appendChild(labelContainer);
          
          // Create and add the marker to the map
          return new mapboxgl.Marker({
            element: markerContainer,
            ...MARKER_SETTINGS,
          })
            .setLngLat(countryData.coordinates)
            .addTo(mapInstance);
        };
        
        // Create and add the info marker if additionalInfo is provided
        const createInfoMarker = () => {
          if (!additionalInfo) return null;
          
          const infoContainer = document.createElement('div');
          infoContainer.className = 'info-container';
          infoContainer.style.backgroundColor = ui.infoBackgroundColor;
          infoContainer.style.color = ui.infoTextColor;
          infoContainer.style.padding = ui.infoPadding;
          infoContainer.style.borderRadius = ui.infoBorderRadius;
          infoContainer.style.fontSize = ui.infoFontSize;
          infoContainer.style.maxWidth = ui.infoMaxWidth;
          infoContainer.style.marginTop = '10px';
          infoContainer.style.opacity = '0'; // Start invisible
          infoContainer.style.boxShadow = ui.infoBoxShadow;
          infoContainer.style.willChange = 'opacity'; // Optimization for animation
          
          // Add info icon before the text
          const infoIconContainer = document.createElement('div');
          infoIconContainer.style.display = 'flex';
          infoIconContainer.style.alignItems = 'center';
          infoIconContainer.style.marginBottom = '5px';
          
          const infoIcon = document.createElement('span');
          infoIcon.innerHTML = renderToString(<FaInfoCircle size={ui.infoIconSize} color={ui.infoIconColor} />);
          infoIcon.style.marginRight = '8px';
          
          infoIconContainer.appendChild(infoIcon);
          infoIconContainer.innerHTML += 'Info:';
          infoContainer.appendChild(infoIconContainer);
          
          // Handle multi-line text with line breaks
          const infoContent = document.createElement('div');
          infoContent.innerHTML = additionalInfo.replace(/\n/g, '<br>');
          infoContainer.appendChild(infoContent);
          
          // Create slightly offset coordinates for info marker
          const infoCoords: [number, number] = [
            countryData.coordinates[0],
            countryData.coordinates[1] - 0.5 // Offset latitude a bit
          ];
          
          return new mapboxgl.Marker({
            element: infoContainer,
            anchor: 'top', // Attach to top
            rotationAlignment: 'viewport', // Keep text aligned with viewport
            pitchAlignment: 'viewport',
          })
            .setLngLat(infoCoords)
            .addTo(mapInstance);
        };
        
        // Create markers
        labelMarkerRef.current = createLabelMarker();
        if (additionalInfo) {
          infoMarkerRef.current = createInfoMarker();
        }
        
        // Ensure everything is rendered before continuing
        mapInstance.once('idle', () => {
          continueRender(initialRenderHandle);
        });
        
        // Safety timeout in case idle event doesn't fire
        setTimeout(() => {
          continueRender(initialRenderHandle);
        }, 5000);
        
      } catch (e) {
        console.error('Error during map setup:', e);
        setHasError(true);
        if (loadTimeout) clearTimeout(loadTimeout);
        continueRender(initialRenderHandle);
      }
    });

    // Handle error event
    mapInstance.on('error', (e) => {
      console.error('Map error:', e.error);
      setHasError(true);
      if (loadTimeout) clearTimeout(loadTimeout);
      continueRender(initialRenderHandle);
    });

    // Cleanup function
    return () => {
      if (loadTimeout) clearTimeout(loadTimeout);
      if (labelMarkerRef.current) labelMarkerRef.current.remove();
      if (infoMarkerRef.current) infoMarkerRef.current.remove();
      if (mapInstance) mapInstance.remove();
    };
  }, [
    initialRenderHandle, 
    countryData, 
    camera.initialPitch, 
    camera.initialRotation, 
    mapStyle, 
    padding, 
    highlight.fillColor, 
    highlight.lineColor, 
    highlight.lineWidth, 
    renderWorldCopies,
    customText,
    shouldShowIcon,
    iconType,
    showText,
    additionalInfo,
    disableFallbackIcon,
    showIcon,
    enableIconDropShadow
  ]);

  // ======================================================================
  // ANIMATION UPDATES
  // ======================================================================
  
  // Update camera and highlight layers every frame
  useEffect(() => {
    if (!mapRef.current) return;
    
    // Create a frame-specific render handle
    const frameHandle = delayRender(`Rendering frame ${frame}`);
    frameRenderHandleRef.current = frameHandle;

    try {
      const mapInstance = mapRef.current;
      
      // Update the camera position
      mapInstance.jumpTo({
        center: animatedCenter,
        zoom: animatedZoom,
        bearing: bearing,
        pitch: pitch,
      });
      
      // Update highlight opacities
      if (mapLayersReady && mapInstance.isStyleLoaded()) {
        // Update fill layer opacity
        try {
          if (mapInstance.getLayer(MAP_LAYER_SETTINGS.countryFill.id)) {
            mapInstance.setPaintProperty(MAP_LAYER_SETTINGS.countryFill.id, 'fill-opacity', fillOpacity);
          }
          
          if (mapInstance.getLayer(MAP_LAYER_SETTINGS.countryOutline.id)) {
            mapInstance.setPaintProperty(MAP_LAYER_SETTINGS.countryOutline.id, 'line-opacity', lineOpacity);
          }
        } catch (error) {
          console.warn('Error updating layer properties:', error);
        }
      }
      
      // Animate main marker
      if (labelMarkerRef.current) {
        const markerElement = labelMarkerRef.current.getElement();
        if (markerElement) {
          const labelContainer = markerElement.querySelector('.label-container');
          if (labelContainer) {
            (labelContainer as HTMLElement).style.opacity = String(labelOpacity);
            markerElement.style.transform = `translateY(${labelY}px) scale(${labelScale})`;
          }
        }
      }
      
      // Animate info marker
      if (infoMarkerRef.current && additionalInfo) {
        const infoElement = infoMarkerRef.current.getElement();
        if (infoElement) {
          infoElement.style.opacity = String(infoOpacity);
        }
      }
      
      // Force a repaint to ensure everything renders
      mapInstance.resize();
      
      // Wait for the map to be idle before allowing the frame to be captured
      mapInstance.once('idle', () => {
        if (frameRenderHandleRef.current === frameHandle) {
          continueRender(frameHandle);
          frameRenderHandleRef.current = null;
        }
      });
      
      // Safety timeout in case idle event doesn't fire
      setTimeout(() => {
        if (frameRenderHandleRef.current === frameHandle) {
          continueRender(frameHandle);
          frameRenderHandleRef.current = null;
        }
      }, 1000);
    } catch (error) {
      console.error('Error in frame update:', error);
      continueRender(frameHandle);
    }
    
    // Cleanup function
    return () => {
      if (frameRenderHandleRef.current === frameHandle) {
        continueRender(frameHandle);
        frameRenderHandleRef.current = null;
      }
    };
  }, [
    frame,
    mapLayersReady, 
    animatedCenter, 
    animatedZoom, 
    bearing, 
    pitch, 
    fillOpacity, 
    lineOpacity,
    labelOpacity,
    labelScale,
    labelY,
    infoOpacity,
    additionalInfo
  ]);

  // ======================================================================
  // RENDER
  // ======================================================================
  
  return (
    <AbsoluteFill style={{ backgroundColor: bgColor }}>
      {hasError ? (
        <div style={ERROR_MESSAGE_SETTINGS}>
          An error occurred while loading the map.
        </div>
      ) : null}
      <AbsoluteFill ref={mapContainerRef} />
    </AbsoluteFill>
  );
};