import React from 'react';
/**
 * ICON REGISTRY
 * 
 * This file serves as a centralized place to define icons available in your application.
 * 
 * TO ADD A NEW ICON:
 * 1. Find an icon you want from any React icons library:
 *    - Font Awesome (fa): https://react-icons.github.io/react-icons/icons?name=fa
 *    - Material Design (md): https://react-icons.github.io/react-icons/icons?name=md
 *    - Game Icons (gi): https://react-icons.github.io/react-icons/icons?name=gi
 *    - And many more: https://react-icons.github.io/react-icons/
 * 
 * 2. Import the icon at the top of this file
 *    Example: import { FaRocket } from 'react-icons/fa';
 * 
 * 3. Add it to the iconRegistry with a simple name
 *    Example: 'rocket': FaRocket,
 * 
 * 4. You can now use it in Composition.tsx via the iconType prop:
 *    <MapboxAnimation iconType="rocket" />
 */

// Import icons from various icon libraries
import { 
  FaMapMarkerAlt, 
  FaInfoCircle, 
  FaFlag, 
  FaSkull, 
  FaMapPin, 
  FaMapMarker, 
  FaCompass, 
  FaLocationArrow, 
  FaExclamationTriangle,
  FaStar
} from 'react-icons/fa';
import { 
  GiDeathSkull, 
  GiCrossMark, 
  GiTargetDummy 
} from 'react-icons/gi';
import { IoLocationSharp } from 'react-icons/io5';
import { MdLocationOn, MdGpsFixed } from 'react-icons/md';

// Define the icon component type
export type IconComponent = React.ComponentType<{
  size?: number;
  color?: string;
  style?: React.CSSProperties;
}>;

/**
 * Icon registry - maps string names to icon components
 * Add new icons here to make them available in your application
 */
export const iconRegistry: Record<string, IconComponent> = {
  // Basic mapping icons
  'marker': FaMapMarkerAlt,
  'pin': FaMapPin,
  'marker-alt': FaMapMarker,
  'location': IoLocationSharp,
  'location-fill': MdLocationOn,
  'compass': FaCompass,
  'arrow': FaLocationArrow,
  'gps': MdGpsFixed,

  // Information and warning icons
  'info': FaInfoCircle,
  'warning': FaExclamationTriangle,
  'cross': GiCrossMark,
  'star': FaStar,

  // Special icons
  'flag': FaFlag,
  'skull': FaSkull,
  'death-skull': GiDeathSkull,
  'target': GiTargetDummy,
};

/**
 * Returns an array of all available icon names
 */
export const getIconNames = (): string[] => {
  return Object.keys(iconRegistry);
};

/**
 * Get a React icon component by name
 * @param iconName Name of the icon to retrieve
 * @returns The React icon component or undefined if not found
 */
export const getIconByName = (iconName: string): IconComponent | null => {
  if (!iconName || iconName === 'none') {
    return null;
  }
  
  return iconRegistry[iconName] || iconRegistry['marker']; // Default to marker if not found
}; 