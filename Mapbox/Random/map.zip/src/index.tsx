import React from 'react';
import { registerRoot } from 'remotion';
import { MyComposition } from './Composition';

// Register the composition for Remotion
registerRoot(() => {
  return <MyComposition />;
}); 